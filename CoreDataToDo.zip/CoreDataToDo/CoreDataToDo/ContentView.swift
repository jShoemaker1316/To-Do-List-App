//
//  ContentView.swift
//  CoreDataToDo
//
//  Created by Jonathan Shoemaker on 5/15/20.
//  Copyright © 2020 JonathanShoemaker. All rights reserved.
//

import SwiftUI
//MARK: this was already a file here and is defined in steps 8 and 9
struct ContentView: View {
    
//10 use property wrapper called environment here. to access the managed object context that we have passed along to our context views environment. Use variabvle to access that within the code here.
    @Environment(\.managedObjectContext) var managedObjectContext
//11 This propert wrapper below allows us to initialize fetchrequest right here which we get from our to-do-item and the getAllToDoItems func that we've defined as a static func. Then declare property called toDoItems with type fetchedresults of toDoItem.
    @FetchRequest(fetchRequest: ToDoItem.getAllToDoItems()) var toDoItems:FetchedResults<ToDoItem>
//12 with thise defined now use a state private variable newToDoItem which we initialize with empty string and using the state property wrapper we can shortly use a text field to get text/string th user uses in a second.
    @State private var newToDoItem = ""
//13 within this body we will use navgiatonView to get a navigation bar title which we will add at the bottom
    var body: some View {
        NavigationView{
//14 add this line of code then delete just so navigationBar stuff can work: Text("fhjythffg")
//17 to get table view add list
            List {
//18 First section of the list is this. we want the header called "Whats next?".
                Section(header: Text("Whats next?")){
//19 now we need to define the text firled and button within a hroizontal stack.
                    HStack {
//20 bind to newToDoItem but we want to always have an up to date version so we use the "$" sign here to access the binding.
                        TextField("New item", text: self.$newToDoItem)
//21 now the button. we need it to have an action( )
//26 now after we set the easy stuff up for the view to test. we can write the func
                        Button(action: {
 //27 create a toDoItem and initialize it with managedObjectContext we already have (using self)
                            let toDoItem = ToDoItem(context: self.managedObjectContext)
//28 use the properties from coredata. the title will be tied to the textField so use newToDoItem
                            toDoItem.title = self.newToDoItem
//29 now use coreData for the createdAT property and just initialize it with date object
                            toDoItem.createdAT = Date()
//30 do catch block to catch errors
                            do {
                                try self.managedObjectContext.save()
                            }catch{
                                print(error)
                            }
 //31 reset storage for newToDoItem so we can create next Item
                            self.newToDoItem = ""
                        }){
//22 the image for the button can be found in SF symbols or from system library.
                            Image(systemName: "plus.cricle.fill")
//23 make the symbol green
                                .foregroundColor(.green)
//24 make the symbol big.
                                .imageScale(.large)
                        }
                    }
//25 define our above section, give it a headline.
                }.font(.headline)
//32 next section, new header
                Section(header: Text("To Do's")) {
//33 ForEach will be used for our toDoItems. Create new file of swiftUIView for ToDoItemView.
                    ForEach(self.toDoItems) {ToDoItem in
//40 use ToDoItemView and its title and date, then unwrap(dont always do this..)
                        ToDoItemView(title: ToDoItem.title!, createdAt: "\(ToDoItem.createdAT!)")
//41 deleting in Swift UI is very easy. .onDelete accesses an indexSet
                    }.onDelete {indexSet in
//42 get delete item within our toDoItems and the first element
                        let deleteItem = self.toDoItems[indexSet.first!]
//43 use managedObjectContext and just delete proper object (which we name deleteItem)
                        self.managedObjectContext.delete(deleteItem)
//44 in case of error. do catch block.
                        do {
                            try self.managedObjectContext.save()
                        }catch{
                            print(error)
                        }
                    }
                }
            }
//15 add navigationView title to the list,  on our nav bar.
            .navigationBarTitle(Text("My List"))
//16 now we need a nav bar item on right side of view(trailing), make it an edit button.
            .navigationBarItems(trailing: EditButton())
        }

    }


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
        }
    }
}
