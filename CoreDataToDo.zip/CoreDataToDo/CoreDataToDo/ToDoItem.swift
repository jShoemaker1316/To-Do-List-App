//
//  ToDoItem.swift
//  CoreDataToDo
//
//  Created by Jonathan Shoemaker on 5/15/20.
//  Copyright © 2020 JonathanShoemaker. All rights reserved.
//

import Foundation
import CoreData
//MARK: create this file to match the entity in Code Data Model

//1 define public class, which inherits from NSManagaedObject, adopt identifiable so each managed object is going to be indetifiable later when used with list.
public class ToDoItem: NSManagedObject, Identifiable {
//2 define our properties using public var
    @NSManaged public var createdAT:Date?
    @NSManaged public var title:String?
}
//3 the simplest thing to do now is add an extension for to-do item because we need to be able to fetch all of the elements that we have in our data.
extension ToDoItem {
//4 Use static func so that we can load all of our items. name it getAllToDoItems. use toDoItem as a type with etch request.
    static func getAllToDoItems() -> NSFetchRequest<ToDoItem> {
        let request:NSFetchRequest<ToDoItem> = ToDoItem.fetchRequest() as! NSFetchRequest<ToDoItem>
 //5 create a sort descriptor to sort elements by createdAt property
        let sortDescriptor = NSSortDescriptor(key: "createdAt", ascending: true)
 //6 use request and pass along sort descriptor within an array. this is expected.
        request.sortDescriptors = [sortDescriptor]
        
        return request
    }
}
