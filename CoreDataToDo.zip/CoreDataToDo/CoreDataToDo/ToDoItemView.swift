//
//  ToDoItemView.swift
//  CoreDataToDo
//
//  Created by Jonathan Shoemaker on 5/15/20.
//  Copyright © 2020 JonathanShoemaker. All rights reserved.
//

import SwiftUI
//34 this file is now created for the toDoItemView struct view
struct ToDoItemView: View {
    var title:String = ""
    var createdAt:String = ""
    
//35 this var body represents the view of the lists
    var body: some View {
//36 give this a Horizontal stack with a Vertical stack within it
        HStack{
            VStack(alignment: .leading){
//37 below is a larger bolder font for the "headline"
                Text(title)
                    .font(.headline)
//38 below comes under the headline and is a smaller text
                Text(createdAt)
                    .font(.caption)
            }
        }
    }
}

struct ToDoItemView_Previews: PreviewProvider {
    static var previews: some View {
// 39 initialize
        ToDoItemView(title: "My great todo", createdAt: "Today")
    }
}
